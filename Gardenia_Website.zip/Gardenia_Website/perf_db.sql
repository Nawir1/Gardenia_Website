-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2023 at 10:24 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perf_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_name` varchar(255) NOT NULL,
  `brand_desc` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_name`, `brand_desc`) VALUES
('Bergdorf Goodman', 'is a luxury department store based on Fifth Avenue in Midtown Manhattan, New York. The company was founded in 1899 by Herman Bergdorf\r\n'),
('Byredo', 'Swedish company that produces fragrances, leather goods, and accessories made in Sweden, founded in Stockholm in 2006 by Ben Gorham'),
('Estée Lauder', 'an American multinational cosmetics company, a manufacturer and marketer of makeup, skincare, fragrance and hair care products, based in Midtown Manhattan, New York City'),
('GUCCI', 'is an Italian high-end luxury fashion house based in Florence, Italy Its product lines include handbags, ready-to-wear, footwear, accessories, and home decoration and fragrance and cosmetics\r\n'),
('Henry Rose', 'Henry Rose Perfume is a perfume brand founded by Michelle Pfeiffer (yes, the most iconic catwoman) in 2019. After giving up fragrance due to not wanting to expose her children to potentially toxic chemicals, Pfeiffer decided to create her own fine fragrance brand that didn’t need to sacrifice safety for luxury');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` varchar(50) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `qty` int(10) NOT NULL,
  `total_price` varchar(100) NOT NULL,
  `product_code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `pmode` varchar(50) NOT NULL,
  `products` varchar(255) NOT NULL,
  `amount_paid` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_price` varchar(100) NOT NULL,
  `product_qty` int(11) NOT NULL DEFAULT 1,
  `product_image` varchar(255) NOT NULL,
  `product_code` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_name`, `product_price`, `product_qty`, `product_image`, `product_code`) VALUES
(1, 'Canadian Tuxedo Extrait de Parfum', '425', 1, '1.jpg', 'p1000'),
(2, 'Bibliotheque Eau de Parfum', '200', 1, '2.jpg', 'p1001'),
(3, 'Jo Malone London', '155', 1, '3.jpg', 'p1002'),
(4, 'Flora Gorgeous Gardenia Eau de Parfum', '155', 1, '4.jpg', 'p1003'),
(5, 'Dark is Night Eau de Parfum', '120', 1, '5.jpg', 'p1004'),
(6, 'Tom Ford Bitter Peach Eau De Parfum', '395', 1, '6.jpg', 'p1005'),
(10, 'Le Labo Patchouli 24 Eau de Parfum', '220', 1, '7.jpg', 'p1006'),
(11, ' The 7 Virtues Patchouli Citrus Eau de Parfum', '88', 1, '8.jpg', 'p1007'),
(12, 'Diptyque Tempo Eau de Parfum', '220', 1, '9.jpg', 'p1008');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password_hash`) VALUES
(1, 'name', 'fayabd99@gmail.com', '$2y$10$diuifPr20Zxe1Lwi468wc.w/z80CAnk7K0irtJh.7TqH7WzC4Ia96'),
(18, 'nouf', 'nouf@gmail.com', '$2y$10$ji6c9626CEyA3ILwgfQLv.p3EUMVqQLXrWp.wxYgMl4zWT7cOlsRS'),
(19, 'raghad', 'raghad@gmail.com', '$2y$10$DQL/PHK.6Isx8BBXG/6zCOpK8HyWUL/DEMU5.3upY05HF82KdMgum'),
(20, 'nwair', 'nwair@gmail.com', '$2y$10$PgIiDhOxks1z0t4HU8gvkuft72Ue5d/30r2EUrbl/07fOqy1yDkRG'),
(21, 'noura', 'noura@gmail.com', '$2y$10$4SRX8Wqs1oIefcJxUXaOjufVit5NBf1Xy8qJLQUTmNPGMsCO7SzUe'),
(22, 'maryam', 'maryam@gmail.com', '$2y$10$xTfNecjJcl5BgsZxP3ssHedhYv.AfRPaX4rbJRPGGdyjHwFp7KCVS'),
(23, 'mona', 'mona@gmail.com', '$2y$10$MSa5cmLA3TshbAqm4CVrZeQ2fTlcnbgEwehn1RNdt5U.kWAz2fCmi'),
(24, 'ZZ', 'ZZ@gmail.com', '$2y$10$PVKe.6VBkY16MwQMDFOPMuaAOGLs5mlJCF5IAu1SIkloiWhDMFHq2'),
(25, 'dd', 'dd@gmail.com', '$2y$10$JIzlBztuY4PM4VPmQm4gjeDsyY04JldzPdZ2s0SsqJH3Ftv7vvSFG');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_code_2` (`product_code`),
  ADD KEY `product_code` (`product_code`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
