<?php

//
session_start();

// close the session

session_destroy();


//go to the main page
header("Location: index.php");
exit;