<?php
	$conn = new mysqli("localhost","root","","cart_system");
	if($conn->connect_error){
		Sdie("Connection Failed!".$conn->connect_error);
	}
?>