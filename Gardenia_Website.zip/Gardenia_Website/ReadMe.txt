we use xamap to build the project

-Firat:connect to the DB and import pref_db file

-Second:open the main page index.php


Enjoy :)

Shahad AlGhareeb 
Fay Alshammari 
Nouf Alghamdi 
Raghad Alamoudi  
Nawir Aldossary

Team 2
